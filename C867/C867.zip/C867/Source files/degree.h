#ifndef DEGREE_H
#define DEGREE_H

//C
enum Degree { SECURITY, NETWORK, SOFTWARE };

#endif 

